package com.seed.unsynch;


public class Test {
	public static void main(String[] args) throws InterruptedException{
		Bank bank = new Bank();
		
		TransactionWindow window = new TransactionWindow(bank);
		window.run();
		
		
	}
}
