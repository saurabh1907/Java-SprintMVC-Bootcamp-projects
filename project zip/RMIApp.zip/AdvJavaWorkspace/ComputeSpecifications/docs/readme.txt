Objective:
------------

To understand RMI protocol.

Modules:
----------

1. compute	
	- This package contains Remote interface 'Compute', which contains remote methods that can be invoked by client.
	- It also contains an interface 'Task', which mandates client to implement task by implementing this interface.
	  
How to run:
--------------

1.	Export jar file into workspace so that TestRMIServer & TestRMIClient can refer them.
	  