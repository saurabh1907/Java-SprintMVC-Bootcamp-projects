Objective:
------------

To understand RMI protocol.

Module:

1. WebContent
	- This web-applications acts as a repository where the server's classes are network accessible.
	- computeSpecs.jar consists of necessary .class files.