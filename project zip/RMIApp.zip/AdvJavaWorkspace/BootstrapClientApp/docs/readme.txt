Objective:
------------

To understand RMI protocol.

Module:

1. WebContent
	- This web-applications acts as a repository where the client serves its classes (the Pi class).
	- It consists of necessary .class files.