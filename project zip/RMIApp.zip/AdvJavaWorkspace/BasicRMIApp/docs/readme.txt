Objective:
------------

To understand basics of RMI.


How to run demo:
---------------------

To run server:

0:	Open command prompt
1:	Change directory to eclipse-project/bin
2:	set JAVA_HOME=c:\Program Files\Java\jdk1.6.0_18
3:	set PATH=%JAVA_HOME%\bin
4:	set CLASSPATH=
5:	start rmiregistry
6:	java com.seed.server.Entry

To run client:
---------------

0:	Open command prompt
1:	Change directory to eclipse-project/bin
2:	set JAVA_HOME=c:\Program Files\Java\jdk1.6.0_18
3:	set PATH=%JAVA_HOME%\bin
4:	set CLASSPATH=
5:	java com.seed.client.Entry


